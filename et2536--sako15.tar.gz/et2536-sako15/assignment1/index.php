<html>
<head>
<link rel="stylesheet" href="style.css" type="text/css"> </link>
</head>

<body>

<br><h1 style="font-family:Trebuchet MS"> <center>To view Graphs</center></h1>
<a href="index1.php"><center><font color=black><input type="submit" name="view" color="black" value="click here"/>
</font></center></a>

<h1 style="font-family:Trebuchet MS"> <center>To add new devices</center></h1>
<a href="index2.php"><center><font color=black><input type="submit" name="view" value="click here"></font></center></a>

<h1 style="font-family:Trebuchet MS"> <center>To remove devices</center></h1>
<a href="index3.php"><center><font color=black><input type="submit" name="view" value="click here"></font></center></a>

</body>
</html>
