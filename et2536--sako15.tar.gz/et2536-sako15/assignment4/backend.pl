#!usr/bin/perl

require "main.pl";
require "table.pl";

table();

while(1)
{
	uptime();

	sleep(30);
}
